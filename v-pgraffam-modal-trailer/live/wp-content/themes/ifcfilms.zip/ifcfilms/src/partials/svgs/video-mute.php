<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="300.6 391.6 11 9.7" enable-background="new 300.6 391.6 11 9.7" xml:space="preserve" width="16px">
  <g>
    <polygon fill="#FFFFFF" points="300.6,394.3 300.6,398.6 302.4,398.6 306.3,401.3 306.3,391.6 302.4,394.3 	"/>
    <polygon fill="#FFFFFF" points="311.6,395.4 310.8,394.6 309.7,395.7 308.5,394.6 307.8,395.4 308.9,396.5 307.8,397.7
      308.5,398.4 309.7,397.3 310.8,398.4 311.6,397.7 310.5,396.5 	"/>
  </g>
</svg>
