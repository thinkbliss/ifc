<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="120.6 0 367.8 792" enable-background="new 120.6 0 367.8 792" xml:space="preserve" width="12px">
  <path fill="#FFFFFF" d="M215.5,792V421.2h-94.9V284.8h94.9c0,0,0-53.4,0-112.7c0-89,56.4-172,183.9-172c53.4,0,89,5.9,89,5.9
	l-3,124.6c0,0-38.6,0-83.1,0c-47.5,0-53.4,20.8-53.4,59.3c0,29.7,0-62.3,0,97.9h139.4l-5.9,133.5H352V792H215.5z"/>
</svg>
