<!-- pagination -->
<div class="pagination">
	<?php ifcfilms_wp_pagination(); ?>
</div>
<!-- /pagination -->
