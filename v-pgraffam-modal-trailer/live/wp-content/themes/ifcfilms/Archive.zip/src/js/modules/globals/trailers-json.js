module.exports =
  [
    {
      "title" : "The Duke of Burgundy",
      "videoId" : 4147491092001,
      "imageURL" : wordpressData.directoryURI + "/images/single/single-duke.jpg",
      "description" : "Description for The Duke of Burgundy"
    },
    {
      "title" : "The Salvation",
      "videoId" : 4147392890001,
      "imageURL" : wordpressData.directoryURI + "/images/single/single-salvation.jpg",
      "description" : "Description for The Salvation"
    },
    {
      "title" : "Match",
      "videoId" : 4147491068001,
      "imageURL" : wordpressData.directoryURI + "/images/single/single-match.jpg",
      "description" : "Description for Match"
    },
    {
      "title" : "Alien Outpost",
      "videoId" : 4147521193001,
      "imageURL" : wordpressData.directoryURI + "/images/single/single-alien.jpg",
      "description" : "Description for Alien Outpost"
    },
    {
      "title" : "Boyhood",
      "videoId" : 4147521180001,
      "imageURL" : wordpressData.directoryURI + "/images/single/single-boyhood.jpg",
      "description" : "Description for Boyhood"
    }
  ];
