<div class="share-fixed text-color hide">
  <p class="text-uppercase share-fixed-header text-smallest">Share</p>
  <a href="#" class="fb-share"><?php get_template_part('partials/svgs/icon', 'fb'); ?></a>
  <a href="#" class="tw-share"><?php get_template_part('partials/svgs/icon', 'tw'); ?></a>
</div>
