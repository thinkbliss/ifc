<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="302.7 392 6.4 8.4" enable-background="new 302.7 392 6.4 8.4" xml:space="preserve" width="8px">
  <polygon fill="#FFFFFF" points="302.7,392 309.1,396.1 302.7,400.3 "/>
</svg>
