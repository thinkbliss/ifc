<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="300.6 391.1 11.4 9.7" enable-background="new 300.6 391.1 11.4 9.7" xml:space="preserve" width="18px">
  <g>
    <polygon fill="#FFFFFF" points="300.6,393.8 300.6,398 302.4,398 306.3,400.8 306.3,391.1 302.4,393.8 	"/>
    <path fill="#FFFFFF" d="M307.7,391.6v1.1c1.8,0,3.3,1.5,3.3,3.3c0,1.8-1.5,3.3-3.3,3.3v1.1c2.4,0,4.3-1.9,4.3-4.3
      C312,393.6,310.1,391.6,307.7,391.6z"/>
    <path fill="#FFFFFF" d="M309.7,395.9c0-1.1-0.9-2-2-2v1.1c0.5,0,0.9,0.4,0.9,0.9c0,0.5-0.4,0.9-0.9,0.9v1.1
      C308.8,397.9,309.7,397,309.7,395.9z"/>
  </g>
</svg>
