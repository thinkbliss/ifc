<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="303.3 392.4 5.7 7" enable-background="new 303.3 392.4 5.7 7" xml:space="preserve" width="8px">
  <rect x="303.3" y="392.4" fill="#FFFFFF" width="1.9" height="7"/>
  <rect x="307.1" y="392.4" fill="#FFFFFF" width="1.9" height="7"/>
</svg>
