<div id="newsletterPopup" class="newsletter-popup">
  <div class="row inline-list">
    <span class="icon-close-popup">X</span> | <span class="icon-email"></span>
    <span class="newsletter-popup-text">SIGN UP FOR THE NEWSLETTER and we'll email you things.</span>
    <input type="email" class="newsletter-popup-email-input" placeholder="Email">
    <a href="#" class="button text-uppercase">Submit</a>
  </div>
</div>