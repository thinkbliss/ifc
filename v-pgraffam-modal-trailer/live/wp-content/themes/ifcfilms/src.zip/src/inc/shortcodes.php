<?php

// add_shortcode('ifcfilms_shortcode_demo', 'ifcfilms_shortcode_demo'); // You can place [ifcfilms_shortcode_demo] in Pages, Posts now.
// add_shortcode('ifcfilms_shortcode_demo_2', 'ifcfilms_shortcode_demo_2'); // Place [ifcfilms_shortcode_demo_2] in Pages, Posts now.

// Shortcode Demo with Nested Capability
// do_shortcode allows for nested Shortcodes
// function ifcfilms_shortcode_demo($atts, $content = null) {
//   return '<div class="shortcode-demo">' . do_shortcode($content) . '</div>';
// }

// Shortcode Demo with simple <h2> tag
// Demo Heading H2 shortcode, allows for nesting within above element. Fully expandable.
// function ifcfilms_shortcode_demo_2($atts, $content = null) {
//   return '<h2>' . $content . '</h2>';
// }
